// Devuelve el color de texto (blanco o negro) con mejor legibilidad sobre un fondo hex.
export function readableTextColor(hex) {
  const value = hex.replace('#', '');
  const [r, g, b] = [0, 2, 4].map((i) => parseInt(value.slice(i, i + 2), 16));
  const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  return luminance > 0.6 ? '#101820' : '#FFFFFF';
}
