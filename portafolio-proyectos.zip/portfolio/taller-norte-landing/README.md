# Taller Norte – Landing page

Sitio de una sola página para un estudio de diseño web, hecho con **HTML5, CSS3, JavaScript (módulos ES) y Tailwind CSS**.

## Funciones
- Diseño responsive con modo claro y oscuro (se recuerda la elección).
- Formulario de contacto con validación accesible.

## Arquitectura y SOLID
| Principio | Dónde se ve |
|---|---|
| S | `ThemeToggle`, `FormController` y `FormValidator` tienen una sola responsabilidad. |
| O | Se agregan reglas nuevas en `validation/rules.js` sin tocar `FormValidator`. |
| L | Todas las reglas cumplen el mismo contrato `{ validate, message }`. |
| I | Cada clase recibe solo lo que necesita (botón, storage, validador). |
| D | `ThemeToggle` depende de un `storage` inyectado, no de `localStorage`. `main.js` arma todo. |

## Estructura
```
index.html
src/
  css/styles.css
  js/  main.js · ThemeToggle.js · FormController.js
       validation/  FormValidator.js · rules.js
```

## Cómo ejecutarlo
Abrí la carpeta con un servidor estático (por ejemplo la extensión Live Server de VS Code o `npx serve .`). Los módulos ES no funcionan abriendo el archivo con doble clic.

Nota: Tailwind se carga por CDN para simplificar el proyecto; en producción conviene compilarlo con su CLI.
