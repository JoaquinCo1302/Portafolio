import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import App from './App.jsx';
import { ColorServiceProvider } from './context/ColorServiceContext.jsx';
import { ColorApiClient } from './services/ColorApiClient.js';

// Raíz de composición: acá se elige la implementación concreta del servicio.
createRoot(document.getElementById('root')).render(
  <StrictMode>
    <ColorServiceProvider service={new ColorApiClient()}>
      <App />
    </ColorServiceProvider>
  </StrictMode>
);
