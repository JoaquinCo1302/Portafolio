// Responsabilidad única: evaluar valores contra reglas inyectadas.
export class FormValidator {
  /** @param {Record<string, {validate: Function, message: string}[]>} schema */
  constructor(schema) {
    this.schema = schema;
  }

  /** @returns {Record<string, string>} mapa campo -> primer mensaje de error */
  validate(values) {
    const errors = {};
    for (const [field, rules] of Object.entries(this.schema)) {
      const failed = rules.find((rule) => !rule.validate(values[field] ?? ''));
      if (failed) errors[field] = failed.message;
    }
    return errors;
  }
}
