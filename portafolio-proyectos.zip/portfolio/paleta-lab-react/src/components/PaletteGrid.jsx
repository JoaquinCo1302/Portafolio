import Swatch from './Swatch.jsx';

export default function PaletteGrid({ colors, loading, error }) {
  if (error) return <p role="alert" className="text-red-700">{error} Probá de nuevo en un momento.</p>;
  if (loading) return <p role="status">Generando paleta…</p>;
  return (
    <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
      {colors.map((color) => <Swatch key={color.hex} {...color} />)}
    </div>
  );
}
