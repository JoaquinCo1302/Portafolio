export default function SeedPicker({ value, onChange }) {
  return (
    <label className="grid gap-1 text-sm font-semibold">
      Color base
      <input type="color" value={value} onChange={(e) => onChange(e.target.value)} className="h-11 w-24 cursor-pointer rounded" />
    </label>
  );
}
