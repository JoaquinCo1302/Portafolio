// Para ofrecer un modo nuevo basta con agregar una fila (abierto/cerrado).
export const SCHEME_MODES = [
  { value: 'analogic', label: 'Análoga' },
  { value: 'complement', label: 'Complementaria' },
  { value: 'triad', label: 'Tríada' },
  { value: 'monochrome', label: 'Monocromática' },
  { value: 'quad', label: 'Cuádruple' },
];
