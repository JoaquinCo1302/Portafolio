export default function ModeSelect({ value, options, onChange }) {
  return (
    <label className="grid gap-1 text-sm font-semibold">
      Tipo de armonía
      <select value={value} onChange={(e) => onChange(e.target.value)} className="h-11 rounded border border-slate-300 bg-white px-3">
        {options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
      </select>
    </label>
  );
}
