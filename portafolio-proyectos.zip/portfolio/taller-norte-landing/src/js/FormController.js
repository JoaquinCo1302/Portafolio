// Responsabilidad única: conectar el formulario del DOM con el validador.
export class FormController {
  constructor({ form, statusEl, validator }) {
    this.form = form;
    this.statusEl = statusEl;
    this.validator = validator;
  }

  init() {
    this.form.addEventListener('submit', (event) => {
      event.preventDefault();
      const values = Object.fromEntries(new FormData(this.form));
      const errors = this.validator.validate(values);
      this.#renderErrors(errors);
      const isValid = Object.keys(errors).length === 0;
      this.statusEl.textContent = isValid ? 'Mensaje listo para enviar. ¡Gracias!' : '';
      if (isValid) this.form.reset();
    });
  }

  #renderErrors(errors) {
    this.form.querySelectorAll('[data-error-for]').forEach((el) => {
      el.textContent = errors[el.dataset.errorFor] ?? '';
    });
  }
}
