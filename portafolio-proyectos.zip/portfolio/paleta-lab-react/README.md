# Paleta Lab

App en **React 18 + Vite + Tailwind CSS 4** que genera paletas de color armónicas a partir de un color base, usando la API pública [The Color API](https://www.thecolorapi.com) (sin clave).

## Funciones
- Selector de color y de tipo de armonía (análoga, complementaria, tríada, etc.).
- Copia del código hex con un clic.
- Texto con contraste automático sobre cada color.
- Estados de carga y de error accesibles.

## Arquitectura y SOLID
| Principio | Dónde se ve |
|---|---|
| S | Cada componente, el hook `usePalette` y el cliente de la API hacen una sola cosa. |
| O | Nuevos modos de armonía: se agrega una fila en `config/schemeModes.js`. |
| L | Cualquier servicio con `getScheme()` puede reemplazar a `ColorApiClient`. |
| I | Los componentes reciben solo las props que usan. |
| D | `usePalette` depende del servicio inyectado por contexto, no de `fetch` directo. |

## Estructura
```
src/
  components/  Swatch · PaletteGrid · SeedPicker · ModeSelect
  config/      schemeModes.js
  context/     ColorServiceContext.jsx
  hooks/       usePalette.js
  services/    ColorApiClient.js
  utils/       contrast.js
  App.jsx · main.jsx · index.css
```

## Cómo ejecutarlo
```bash
npm install
npm run dev
```
