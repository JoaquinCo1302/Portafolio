# Portafolio – Joaquín Ismael Coppa

| Proyecto | Tecnologías |
|---|---|
| [taller-norte-landing](./taller-norte-landing) | HTML5, CSS3, JavaScript, Tailwind CSS |
| [paleta-lab-react](./paleta-lab-react) | React, Vite, Tailwind CSS, API REST |

Cada carpeta es un proyecto independiente: podés subirlas como repositorios separados o juntas en uno solo.
