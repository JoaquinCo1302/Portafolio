import { ThemeToggle } from './ThemeToggle.js';
import { FormController } from './FormController.js';
import { FormValidator } from './validation/FormValidator.js';
import { required, email, minLength } from './validation/rules.js';

// Raíz de composición: acá se crean y conectan las dependencias.
const storage = {
  get: (key) => { try { return localStorage.getItem(key); } catch { return null; } },
  set: (key, value) => { try { localStorage.setItem(key, value); } catch { /* sin almacenamiento */ } },
};

new ThemeToggle({
  button: document.getElementById('theme-toggle'),
  root: document.documentElement,
  storage,
}).init();

new FormController({
  form: document.getElementById('contact-form'),
  statusEl: document.getElementById('form-status'),
  validator: new FormValidator({
    name: [required()],
    email: [required(), email()],
    message: [required(), minLength(10)],
  }),
}).init();
