// Cada regla cumple el mismo contrato { validate(value) -> boolean, message }.
// Para sumar una regla nueva no se modifica FormValidator (principio abierto/cerrado).
export const required = (message = 'Este campo es obligatorio.') => ({
  validate: (value) => value.trim().length > 0,
  message,
});

export const email = (message = 'Ingresá un correo válido.') => ({
  validate: (value) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value),
  message,
});

export const minLength = (min, message = `Escribí al menos ${min} caracteres.`) => ({
  validate: (value) => value.trim().length >= min,
  message,
});
