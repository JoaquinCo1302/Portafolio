import { useEffect, useState } from 'react';
import { useColorService } from '../context/ColorServiceContext.jsx';

// Responsabilidad única: pedir la paleta y exponer { colors, loading, error }.
export function usePalette(hex, mode) {
  const service = useColorService();
  const [state, setState] = useState({ colors: [], loading: true, error: null });

  useEffect(() => {
    const controller = new AbortController();
    setState((s) => ({ ...s, loading: true, error: null }));
    service
      .getScheme({ hex: hex.replace('#', ''), mode, signal: controller.signal })
      .then((colors) => setState({ colors, loading: false, error: null }))
      .catch((error) => {
        if (error.name !== 'AbortError') setState({ colors: [], loading: false, error: error.message });
      });
    return () => controller.abort();
  }, [service, hex, mode]);

  return state;
}
