// Depende de una abstracción de almacenamiento (get/set), no de localStorage.
export class ThemeToggle {
  constructor({ button, root, storage, key = 'theme' }) {
    this.button = button;
    this.root = root;
    this.storage = storage;
    this.key = key;
  }

  init() {
    this.#apply(this.storage.get(this.key) === 'dark');
    this.button.addEventListener('click', () => this.#apply(!this.root.classList.contains('dark')));
  }

  #apply(isDark) {
    this.root.classList.toggle('dark', isDark);
    this.storage.set(this.key, isDark ? 'dark' : 'light');
  }
}
