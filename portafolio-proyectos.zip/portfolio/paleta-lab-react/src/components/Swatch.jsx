import { useState } from 'react';
import { readableTextColor } from '../utils/contrast.js';

export default function Swatch({ hex, name }) {
  const [copied, setCopied] = useState(false);

  const copy = async () => {
    await navigator.clipboard.writeText(hex);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <button
      type="button"
      onClick={copy}
      style={{ backgroundColor: hex, color: readableTextColor(hex) }}
      className="flex h-44 flex-col justify-end rounded-lg p-4 text-left"
    >
      <span className="text-lg font-semibold">{copied ? 'Copiado' : hex}</span>
      <span className="text-sm opacity-80">{name}</span>
    </button>
  );
}
