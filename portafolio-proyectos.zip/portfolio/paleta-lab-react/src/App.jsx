import { useState } from 'react';
import SeedPicker from './components/SeedPicker.jsx';
import ModeSelect from './components/ModeSelect.jsx';
import PaletteGrid from './components/PaletteGrid.jsx';
import { SCHEME_MODES } from './config/schemeModes.js';
import { usePalette } from './hooks/usePalette.js';

export default function App() {
  const [seed, setSeed] = useState('#3D5AFE');
  const [mode, setMode] = useState(SCHEME_MODES[0].value);
  const palette = usePalette(seed, mode);

  return (
    <main className="mx-auto max-w-5xl px-6 py-12">
      <h1 className="text-4xl font-extrabold md:text-5xl">Paleta Lab</h1>
      <p className="mt-3 max-w-xl text-slate-600">Elegí un color base y generá una paleta armónica. Hacé clic en un color para copiar su código.</p>
      <div className="my-8 flex flex-wrap items-end gap-6">
        <SeedPicker value={seed} onChange={setSeed} />
        <ModeSelect value={mode} options={SCHEME_MODES} onChange={setMode} />
      </div>
      <PaletteGrid {...palette} />
    </main>
  );
}
