// Implementación del contrato: getScheme({ hex, mode, count, signal }) -> [{ hex, name }]
// Usa The Color API (https://www.thecolorapi.com), gratuita y sin clave.
export class ColorApiClient {
  constructor(baseUrl = 'https://www.thecolorapi.com') {
    this.baseUrl = baseUrl;
  }

  async getScheme({ hex, mode, count = 5, signal }) {
    const url = `${this.baseUrl}/scheme?hex=${hex}&mode=${mode}&count=${count}`;
    const response = await fetch(url, { signal });
    if (!response.ok) throw new Error('No se pudo obtener la paleta.');
    const data = await response.json();
    return data.colors.map((c) => ({ hex: c.hex.value, name: c.name.value }));
  }
}
