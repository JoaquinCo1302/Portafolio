import { createContext, useContext } from 'react';

const ColorServiceContext = createContext(null);

export function ColorServiceProvider({ service, children }) {
  return <ColorServiceContext.Provider value={service}>{children}</ColorServiceContext.Provider>;
}

export function useColorService() {
  const service = useContext(ColorServiceContext);
  if (!service) throw new Error('Falta ColorServiceProvider.');
  return service;
}
